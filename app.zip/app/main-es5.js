function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"], {
  /***/
  "./$$_lazy_route_resource lazy recursive":
  /*!******************************************************!*\
    !*** ./$$_lazy_route_resource lazy namespace object ***!
    \******************************************************/

  /*! no static exports found */

  /***/
  function $$_lazy_route_resourceLazyRecursive(module, exports) {
    function webpackEmptyAsyncContext(req) {
      // Here Promise.resolve().then() is used instead of new Promise() to prevent
      // uncaught exception popping up in devtools
      return Promise.resolve().then(function () {
        var e = new Error("Cannot find module '" + req + "'");
        e.code = 'MODULE_NOT_FOUND';
        throw e;
      });
    }

    webpackEmptyAsyncContext.keys = function () {
      return [];
    };

    webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
    module.exports = webpackEmptyAsyncContext;
    webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";
    /***/
  },

  /***/
  "./src/app/Details.ts":
  /*!****************************!*\
    !*** ./src/app/Details.ts ***!
    \****************************/

  /*! exports provided: Details */

  /***/
  function srcAppDetailsTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Details", function () {
      return Details;
    });

    var Details = function Details(trackid, status) {
      var dataJson = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : "";
      var responseMessage = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : "";
      var eventGroupId = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : 0;

      _classCallCheck(this, Details);

      this.trackerId = trackid;
      this.status = status;
      this.dataJson = dataJson;
      this.responseMessage = responseMessage;
      this.eventGroupId = eventGroupId;
    };
    /***/

  },

  /***/
  "./src/app/Details2.ts":
  /*!*****************************!*\
    !*** ./src/app/Details2.ts ***!
    \*****************************/

  /*! exports provided: Details2 */

  /***/
  function srcAppDetails2Ts(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Details2", function () {
      return Details2;
    });

    var Details2 = function Details2(trackid, status) {
      var responseMessage = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : "";
      var eventGroupId = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 0;

      _classCallCheck(this, Details2);

      this.trackerId = trackid;
      this.status = status;
      this.responseMessage = responseMessage;
      this.eventGroupId = eventGroupId;
    };
    /***/

  },

  /***/
  "./src/app/app-routing.module.ts":
  /*!***************************************!*\
    !*** ./src/app/app-routing.module.ts ***!
    \***************************************/

  /*! exports provided: AppRoutingModule */

  /***/
  function srcAppAppRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function () {
      return AppRoutingModule;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _home_home_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./home/home.component */
    "./src/app/home/home.component.ts");
    /* harmony import */


    var _schedule_schedule_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./schedule/schedule.component */
    "./src/app/schedule/schedule.component.ts");
    /* harmony import */


    var _update_update_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./update/update.component */
    "./src/app/update/update.component.ts");
    /* harmony import */


    var _update_events_details_update_events_details_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./update-events-details/update-events-details.component */
    "./src/app/update-events-details/update-events-details.component.ts");

    var routes = [{
      path: "home",
      component: _home_home_component__WEBPACK_IMPORTED_MODULE_2__["HomeComponent"],
      pathMatch: "full"
    }, {
      path: "schedule",
      component: _schedule_schedule_component__WEBPACK_IMPORTED_MODULE_3__["ScheduleComponent"],
      pathMatch: "full"
    }, {
      path: "update",
      component: _update_update_component__WEBPACK_IMPORTED_MODULE_4__["UpdateComponent"],
      pathMatch: "full"
    }, {
      path: "updateeventsdetails",
      component: _update_events_details_update_events_details_component__WEBPACK_IMPORTED_MODULE_5__["UpdateEventsDetailsComponent"],
      pathMatch: "full"
    }, {
      path: "",
      redirectTo: "home",
      // component: HomeComponent,
      pathMatch: "full"
    }];

    var AppRoutingModule = function AppRoutingModule() {
      _classCallCheck(this, AppRoutingModule);
    };

    AppRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
      type: AppRoutingModule
    });
    AppRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
      factory: function AppRoutingModule_Factory(t) {
        return new (t || AppRoutingModule)();
      },
      imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
    });

    (function () {
      (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](AppRoutingModule, {
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
      });
    })();
    /*@__PURE__*/


    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AppRoutingModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
          declarations: [],
          imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes)],
          exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
        }]
      }], null, null);
    })();
    /***/

  },

  /***/
  "./src/app/app.component.ts":
  /*!**********************************!*\
    !*** ./src/app/app.component.ts ***!
    \**********************************/

  /*! exports provided: AppComponent */

  /***/
  function srcAppAppComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppComponent", function () {
      return AppComponent;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _navbar_navbar_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./navbar/navbar.component */
    "./src/app/navbar/navbar.component.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");

    var AppComponent = function AppComponent() {
      _classCallCheck(this, AppComponent);

      this.title = 'app';
    };

    AppComponent.ɵfac = function AppComponent_Factory(t) {
      return new (t || AppComponent)();
    };

    AppComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: AppComponent,
      selectors: [["app-root"]],
      decls: 2,
      vars: 0,
      template: function AppComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "app-navbar");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "router-outlet");
        }
      },
      directives: [_navbar_navbar_component__WEBPACK_IMPORTED_MODULE_1__["NavbarComponent"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterOutlet"]],
      styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuY3NzIn0= */"]
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AppComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
          selector: 'app-root',
          templateUrl: './app.component.html',
          styleUrls: ['./app.component.css']
        }]
      }], null, null);
    })();
    /***/

  },

  /***/
  "./src/app/app.module.ts":
  /*!*******************************!*\
    !*** ./src/app/app.module.ts ***!
    \*******************************/

  /*! exports provided: AppModule */

  /***/
  function srcAppAppModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppModule", function () {
      return AppModule;
    });
    /* harmony import */


    var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/platform-browser */
    "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _app_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./app.component */
    "./src/app/app.component.ts");
    /* harmony import */


    var _schedule_schedule_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./schedule/schedule.component */
    "./src/app/schedule/schedule.component.ts");
    /* harmony import */


    var _update_update_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./update/update.component */
    "./src/app/update/update.component.ts");
    /* harmony import */


    var _navbar_navbar_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./navbar/navbar.component */
    "./src/app/navbar/navbar.component.ts");
    /* harmony import */


    var _app_routing_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./app-routing.module */
    "./src/app/app-routing.module.ts");
    /* harmony import */


    var _home_home_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ./home/home.component */
    "./src/app/home/home.component.ts");
    /* harmony import */


    var _update_events_details_update_events_details_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ./update-events-details/update-events-details.component */
    "./src/app/update-events-details/update-events-details.component.ts");

    var AppModule = function AppModule() {
      _classCallCheck(this, AppModule);
    };

    AppModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({
      type: AppModule,
      bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"]]
    });
    AppModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({
      factory: function AppModule_Factory(t) {
        return new (t || AppModule)();
      },
      providers: [],
      imports: [[_angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"], _app_routing_module__WEBPACK_IMPORTED_MODULE_7__["AppRoutingModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"]]]
    });

    (function () {
      (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](AppModule, {
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"], _schedule_schedule_component__WEBPACK_IMPORTED_MODULE_4__["ScheduleComponent"], _update_update_component__WEBPACK_IMPORTED_MODULE_5__["UpdateComponent"], _navbar_navbar_component__WEBPACK_IMPORTED_MODULE_6__["NavbarComponent"], _home_home_component__WEBPACK_IMPORTED_MODULE_8__["HomeComponent"], _update_events_details_update_events_details_component__WEBPACK_IMPORTED_MODULE_9__["UpdateEventsDetailsComponent"]],
        imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"], _app_routing_module__WEBPACK_IMPORTED_MODULE_7__["AppRoutingModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"]]
      });
    })();
    /*@__PURE__*/


    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵsetClassMetadata"](AppModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"],
        args: [{
          declarations: [_app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"], _schedule_schedule_component__WEBPACK_IMPORTED_MODULE_4__["ScheduleComponent"], _update_update_component__WEBPACK_IMPORTED_MODULE_5__["UpdateComponent"], _navbar_navbar_component__WEBPACK_IMPORTED_MODULE_6__["NavbarComponent"], _home_home_component__WEBPACK_IMPORTED_MODULE_8__["HomeComponent"], _update_events_details_update_events_details_component__WEBPACK_IMPORTED_MODULE_9__["UpdateEventsDetailsComponent"]],
          imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"], _app_routing_module__WEBPACK_IMPORTED_MODULE_7__["AppRoutingModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"]],
          providers: [],
          bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"]]
        }]
      }], null, null);
    })();
    /***/

  },

  /***/
  "./src/app/home/home.component.ts":
  /*!****************************************!*\
    !*** ./src/app/home/home.component.ts ***!
    \****************************************/

  /*! exports provided: HomeComponent */

  /***/
  function srcAppHomeHomeComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomeComponent", function () {
      return HomeComponent;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

    var HomeComponent =
    /*#__PURE__*/
    function () {
      function HomeComponent() {
        _classCallCheck(this, HomeComponent);
      }

      _createClass(HomeComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return HomeComponent;
    }();

    HomeComponent.ɵfac = function HomeComponent_Factory(t) {
      return new (t || HomeComponent)();
    };

    HomeComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: HomeComponent,
      selectors: [["app-home"]],
      decls: 0,
      vars: 0,
      template: function HomeComponent_Template(rf, ctx) {},
      styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2hvbWUvaG9tZS5jb21wb25lbnQuY3NzIn0= */"]
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](HomeComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
          selector: 'app-home',
          templateUrl: './home.component.html',
          styleUrls: ['./home.component.css']
        }]
      }], function () {
        return [];
      }, null);
    })();
    /***/

  },

  /***/
  "./src/app/navbar/navbar.component.ts":
  /*!********************************************!*\
    !*** ./src/app/navbar/navbar.component.ts ***!
    \********************************************/

  /*! exports provided: NavbarComponent */

  /***/
  function srcAppNavbarNavbarComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NavbarComponent", function () {
      return NavbarComponent;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");

    var NavbarComponent =
    /*#__PURE__*/
    function () {
      function NavbarComponent() {
        _classCallCheck(this, NavbarComponent);
      }

      _createClass(NavbarComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return NavbarComponent;
    }();

    NavbarComponent.ɵfac = function NavbarComponent_Factory(t) {
      return new (t || NavbarComponent)();
    };

    NavbarComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: NavbarComponent,
      selectors: [["app-navbar"]],
      decls: 17,
      vars: 0,
      consts: [[1, "navbar", "navbar-expand-lg", "navbar-light", "bg-dark"], ["type", "button", "data-toggle", "collapse", "data-target", "#navbarNav", "aria-controls", "navbarNav", "aria-expanded", "false", "aria-label", "Toggle navigation", 1, "navbar-toggler"], [1, "navbar-toggler-icon"], ["id", "navbarNav", 1, "collapse", "navbar-collapse"], [1, "navbar-nav"], [1, "nav-item"], ["routerLink", "home", "routerLinkActive", "activeLink", 1, "nav-link"], ["routerLink", "schedule", "routerLinkActive", "activeLink", 1, "nav-link"], ["routerLink", "update", "routerLinkActive", "activeLink", 1, "nav-link"], ["routerLink", "updateeventsdetails", "routerLinkActive", "activeLink", 1, "nav-link"]],
      template: function NavbarComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "nav", 0);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "button", 1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "span", 2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "ul", 4);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "li", 5);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "a", 6);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "Home");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "li", 5);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "a", 7);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "Schedule Event");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "li", 5);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "a", 8);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, "Update Event");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "li", 5);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "a", 9);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, "Update Event Details");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      },
      directives: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterLinkWithHref"], _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterLinkActive"]],
      styles: [".nav-item[_ngcontent-%COMP%]   .nav-link[_ngcontent-%COMP%] {\r\n  color: white;\r\n  \r\n  \r\n  \r\n  \r\n  \r\n  \r\n}\r\n.nav-item[_ngcontent-%COMP%] {\r\n  display: block;\r\n  \r\n  margin-left: 20px;\r\n  width: 200px;\r\n  text-align: center;\r\n  \r\n}\r\n.activeLink[_ngcontent-%COMP%] {\r\n  background-color: gray;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbmF2YmFyL25hdmJhci5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsWUFBWTtFQUNaLDJCQUEyQjtFQUMzQixtQkFBbUI7RUFDbkIsdUJBQXVCO0VBQ3ZCLGtCQUFrQjtFQUNsQixvQkFBb0I7RUFDcEIsa0JBQWtCO0FBQ3BCO0FBQ0E7RUFDRSxjQUFjO0VBQ2QscUNBQXFDO0VBQ3JDLGlCQUFpQjtFQUNqQixZQUFZO0VBQ1osa0JBQWtCO0VBQ2xCLHVCQUF1QjtBQUN6QjtBQUVBO0VBQ0Usc0JBQXNCO0FBQ3hCIiwiZmlsZSI6InNyYy9hcHAvbmF2YmFyL25hdmJhci5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm5hdi1pdGVtIC5uYXYtbGluayB7XHJcbiAgY29sb3I6IHdoaXRlO1xyXG4gIC8qIGJvcmRlcjogMnB4IHNvbGlkIHJlZDsgKi9cclxuICAvKiBwYWRkaW5nOiAxMHB4OyAqL1xyXG4gIC8qIG1hcmdpbi1sZWZ0OiAxMHB4OyAqL1xyXG4gIC8qIGhlaWdodDogNTBweDsgKi9cclxuICAvKiBkaXNwbGF5OiBibG9jazsgKi9cclxuICAvKiB3aWR0aDogMTAwcHg7ICovXHJcbn1cclxuLm5hdi1pdGVtIHtcclxuICBkaXNwbGF5OiBibG9jaztcclxuICAvKiBib3JkZXI6IDJweCBzb2xpZCBwYWxldmlvbGV0cmVkOyAqL1xyXG4gIG1hcmdpbi1sZWZ0OiAyMHB4O1xyXG4gIHdpZHRoOiAyMDBweDtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgLyogbWFyZ2luLWJvdHRvbTogMCU7ICovXHJcbn1cclxuXHJcbi5hY3RpdmVMaW5rIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiBncmF5O1xyXG59XHJcbiJdfQ== */"]
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NavbarComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
          selector: "app-navbar",
          templateUrl: "./navbar.component.html",
          styleUrls: ["./navbar.component.css"]
        }]
      }], function () {
        return [];
      }, null);
    })();
    /***/

  },

  /***/
  "./src/app/schedule.service.ts":
  /*!*************************************!*\
    !*** ./src/app/schedule.service.ts ***!
    \*************************************/

  /*! exports provided: ScheduleService */

  /***/
  function srcAppScheduleServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ScheduleService", function () {
      return ScheduleService;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _schedule_schedull__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./schedule/schedull */
    "./src/app/schedule/schedull.ts");

    var ScheduleService =
    /*#__PURE__*/
    function () {
      function ScheduleService() {
        _classCallCheck(this, ScheduleService);

        this.entry = [];
      }

      _createClass(ScheduleService, [{
        key: "add",
        value: function add(tracking) {
          this.entry.push(new _schedule_schedull__WEBPACK_IMPORTED_MODULE_1__["Schedule"](tracking));
        } // get(): Schedule[] {
        //   return this.entry;
        // }

      }, {
        key: "getjson",
        value: function getjson() {
          return JSON.stringify(this.entry, null, "\t");
        }
      }]);

      return ScheduleService;
    }();

    ScheduleService.ɵfac = function ScheduleService_Factory(t) {
      return new (t || ScheduleService)();
    };

    ScheduleService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
      token: ScheduleService,
      factory: ScheduleService.ɵfac,
      providedIn: "root"
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ScheduleService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
          providedIn: "root"
        }]
      }], function () {
        return [];
      }, null);
    })();
    /***/

  },

  /***/
  "./src/app/schedule/schedule.component.ts":
  /*!************************************************!*\
    !*** ./src/app/schedule/schedule.component.ts ***!
    \************************************************/

  /*! exports provided: ScheduleComponent */

  /***/
  function srcAppScheduleScheduleComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ScheduleComponent", function () {
      return ScheduleComponent;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _schedule_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ../schedule.service */
    "./src/app/schedule.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");

    var ScheduleComponent =
    /*#__PURE__*/
    function () {
      function ScheduleComponent(service) {
        _classCallCheck(this, ScheduleComponent);

        this.service = service;
        this.table = false;
        this.environment = "";
      }

      _createClass(ScheduleComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "onAdd",
        value: function onAdd(env, id) {
          var _this = this;

          console.log(env, id);
          this.environment = env;
          this.trackerId = id.split(",");
          this.trackerId.forEach(function (t, i) {
            // this.trackingNew[i] = Number(t);
            // console.log(t);
            _this.trackerId[i] = Number(t);
          }); // console.log(this.trackingNew);
          // console.log(this.tracking);

          this.table = true;
          this.service.add(this.trackerId);
          this.entries = this.service.getjson();
        }
      }, {
        key: "clear",
        value: function clear(form1) {
          form1.reset();
        }
      }, {
        key: "copyInputMessage",
        value: function copyInputMessage(inputElement) {
          inputElement.select();
          document.execCommand("copy");
          inputElement.setSelectionRange(0, 0);
        }
      }]);

      return ScheduleComponent;
    }();

    ScheduleComponent.ɵfac = function ScheduleComponent_Factory(t) {
      return new (t || ScheduleComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_schedule_service__WEBPACK_IMPORTED_MODULE_1__["ScheduleService"]));
    };

    ScheduleComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: ScheduleComponent,
      selectors: [["app-schedule"]],
      decls: 32,
      vars: 1,
      consts: [[1, "container", "mt-5"], ["form1", ""], [1, "form-group", "row", "justify-content-center"], ["for", "evnviornment", 1, "col-sm-2", "col-form-label"], [1, "col-3"], ["id", "evnviornment", 1, "form-control"], ["environment", ""], ["for", "trackingId", 1, "col-sm-2", "col-form-label"], ["type", "text", "id", "trackingId", 1, "form-control"], ["trackingId", ""], ["type", "button", 1, "btn", "btn-primary", "col-2", 3, "click"], [1, "form-group", "row", "justify-content-center", "mt-5", 2, "width", "45%", "margin", "auto"], ["rows", "10", 1, "form-control"], ["jsondata", ""], ["value", "click to copy", 1, "my-5", "btn", "btn-success", 3, "click"]],
      template: function ScheduleComponent_Template(rf, ctx) {
        if (rf & 1) {
          var _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "form", null, 1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "label", 3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "Environment");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 4);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "select", 5, 6);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "option");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "DEV");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "option");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, "QA");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "option");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14, "UAT");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "option");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, "PROD");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "div", 2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "label", 7);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](19, "Tracker Id's");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "div", 4);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](21, "input", 8, 9);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "div", 2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "button", 10);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ScheduleComponent_Template_button_click_24_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r4);

            var _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](8);

            var _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](22);

            return ctx.onAdd(_r1.value, _r2.value);
          })("click", function ScheduleComponent_Template_button_click_24_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r4);

            var _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](2);

            return ctx.clear(_r0);
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](25, " Schedule ");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "div", 11);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "textarea", 12, 13);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](29);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](30, "button", 14);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ScheduleComponent_Template_button_click_30_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r4);

            var _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](28);

            return ctx.copyInputMessage(_r3);
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](31, " Copy ");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](29);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.entries);
        }
      },
      directives: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgForm"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgSelectOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵangular_packages_forms_forms_x"]],
      styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NjaGVkdWxlL3NjaGVkdWxlLmNvbXBvbmVudC5jc3MifQ== */"]
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ScheduleComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
          selector: "app-schedule",
          templateUrl: "./schedule.component.html",
          styleUrls: ["./schedule.component.css"]
        }]
      }], function () {
        return [{
          type: _schedule_service__WEBPACK_IMPORTED_MODULE_1__["ScheduleService"]
        }];
      }, null);
    })();
    /***/

  },

  /***/
  "./src/app/schedule/schedull.ts":
  /*!**************************************!*\
    !*** ./src/app/schedule/schedull.ts ***!
    \**************************************/

  /*! exports provided: Schedule */

  /***/
  function srcAppScheduleSchedullTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Schedule", function () {
      return Schedule;
    });

    var Schedule = // status: string;
    function Schedule(tracking) {
      _classCallCheck(this, Schedule);

      // this.environment = env;
      this.trackerId = tracking; // this.status = status;
    };
    /***/

  },

  /***/
  "./src/app/update-events-details/update-events-details.component.ts":
  /*!**************************************************************************!*\
    !*** ./src/app/update-events-details/update-events-details.component.ts ***!
    \**************************************************************************/

  /*! exports provided: UpdateEventsDetailsComponent */

  /***/
  function srcAppUpdateEventsDetailsUpdateEventsDetailsComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "UpdateEventsDetailsComponent", function () {
      return UpdateEventsDetailsComponent;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _update_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ../update.service */
    "./src/app/update.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");

    function UpdateEventsDetailsComponent_div_30_Template(rf, ctx) {
      if (rf & 1) {
        var _r35 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 20);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "label", 21);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Data JSON");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 5);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "input", 22);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function UpdateEventsDetailsComponent_div_30_Template_input_ngModelChange_4_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r35);

          var ctx_r34 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r34.dataJson = $event;
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "button", 23);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function UpdateEventsDetailsComponent_div_30_Template_button_click_5_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r35);

          var ctx_r36 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r36.hide_data();
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, " Delete ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var ctx_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx_r28.dataJson);
      }
    }

    function UpdateEventsDetailsComponent_div_31_Template(rf, ctx) {
      if (rf & 1) {
        var _r39 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 20);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "label", 24);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "event");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 5);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "input", 25, 26);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function UpdateEventsDetailsComponent_div_31_Template_input_ngModelChange_4_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r39);

          var ctx_r38 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r38.event = $event;
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "button", 23);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function UpdateEventsDetailsComponent_div_31_Template_button_click_6_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r39);

          var ctx_r40 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r40.hide_eventGroupId();
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, " Delete ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var ctx_r29 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx_r29.event);
      }
    }

    function UpdateEventsDetailsComponent_div_32_Template(rf, ctx) {
      if (rf & 1) {
        var _r42 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 20);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "label", 27);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Response Message");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 5);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "input", 28);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function UpdateEventsDetailsComponent_div_32_Template_input_ngModelChange_4_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r42);

          var ctx_r41 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r41.responseMsg = $event;
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "button", 23);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function UpdateEventsDetailsComponent_div_32_Template_button_click_5_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r42);

          var ctx_r43 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r43.hide_res();
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, " Delete ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var ctx_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx_r30.responseMsg);
      }
    }

    function UpdateEventsDetailsComponent_div_33_Template(rf, ctx) {
      if (rf & 1) {
        var _r46 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 20);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "label", 29);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "serviceConsumerKey");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 5);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "input", 30, 26);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function UpdateEventsDetailsComponent_div_33_Template_input_ngModelChange_4_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r46);

          var ctx_r45 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r45.serviceConsumerKey = $event;
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "button", 23);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function UpdateEventsDetailsComponent_div_33_Template_button_click_6_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r46);

          var ctx_r47 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r47.hide_serviceConsumerKey();
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, " Delete ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var ctx_r31 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx_r31.serviceConsumerKey);
      }
    }

    function UpdateEventsDetailsComponent_div_34_Template(rf, ctx) {
      if (rf & 1) {
        var _r50 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 20);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "label", 31);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "transactionRawJson");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 5);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "input", 32, 26);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function UpdateEventsDetailsComponent_div_34_Template_input_ngModelChange_4_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r50);

          var ctx_r49 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r49.transactionRawJson = $event;
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "button", 23);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function UpdateEventsDetailsComponent_div_34_Template_button_click_6_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r50);

          var ctx_r51 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r51.hide_transactionRawJson();
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, " Delete ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx_r32.transactionRawJson);
      }
    }

    var UpdateEventsDetailsComponent =
    /*#__PURE__*/
    function () {
      function UpdateEventsDetailsComponent(service) {
        _classCallCheck(this, UpdateEventsDetailsComponent);

        this.service = service;
        this.environment = "";
        this.status = "";
        this.table = false;
        this.details = {};
        this.trackerArray = [];
        this.add = false;
        this.hideResponse = false;
        this.hidedataJson = false;
        this.hideserviceConsumerKey = false;
        this.hideconformationId = false;
        this.hidetransactionRawJson = false;
        this.hideeventGroupId = false;
      }

      _createClass(UpdateEventsDetailsComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "onAdd",
        value: function onAdd(env, id, status) {
          this.environment = env;
          this.trackerId = id;
          this.status = status.toUpperCase(); // if (this.eventGroupId == "") this.eventGroupId = 0;

          if (!this.hidedataJson) {
            this.service.withoutDataJsonUED(this.environment, this.trackerId, this.status, this.event, this.responseMsg, this.serviceConsumerKey, this.transactionRawJson);
            this.json = this.service.getjsonupdateeventdetails();
          } else {
            if (String(this.dataJson).length > 0) {
              this.service.addUpdateEventDetails(this.environment, this.trackerId, this.status, this.dataJson, this.event, this.responseMsg, this.serviceConsumerKey, this.transactionRawJson);
              this.json = this.service.getjsonupdateeventdetails();
            } else {
              this.service.withoutDataJsonUED(this.environment, this.trackerId, this.status, this.event, this.responseMsg, this.serviceConsumerKey, this.transactionRawJson);
              this.json = this.service.getjsonupdateeventdetails();
            }
          }

          console.log(this.json);
          this.dataJson = "";
          this.responseMsg = "";
          this.serviceConsumerKey = "";
          this.conformationId = "";
          this.event = "";
          this.transactionRawJson = "";
          this.hideResponse = false;
          this.hidedataJson = false;
          this.hideserviceConsumerKey = false;
          this.hideconformationId = false;
          this.hidetransactionRawJson = false;
          this.hideeventGroupId = false;
        }
      }, {
        key: "copyInputMessage",
        value: function copyInputMessage(inputElement) {
          inputElement.select();
          document.execCommand("copy");
          inputElement.setSelectionRange(0, 0);
        }
      }, {
        key: "onAddMore",
        value: function onAddMore() {
          this.hidedataJson = true;
          this.hideResponse = true;
          this.hideserviceConsumerKey = true;
          this.hideconformationId = true;
          this.hidetransactionRawJson = true;
          this.hideeventGroupId = true;
        }
      }, {
        key: "clear",
        value: function clear(form2) {
          form2.reset();
        }
      }, {
        key: "hide_data",
        value: function hide_data() {
          this.hidedataJson = false;
          this.dataJson = "";
        }
      }, {
        key: "hide_res",
        value: function hide_res() {
          this.hideResponse = false;
          this.responseMsg = "";
        }
      }, {
        key: "hide_serviceConsumerKey",
        value: function hide_serviceConsumerKey() {
          this.hideserviceConsumerKey = false;
          this.serviceConsumerKey = "";
        }
      }, {
        key: "hide_conformationId",
        value: function hide_conformationId() {
          this.hideconformationId = false;
          this.conformationId = "";
        }
      }, {
        key: "hide_transactionRawJson",
        value: function hide_transactionRawJson() {
          this.hidetransactionRawJson = false;
          this.transactionRawJson = "";
        }
      }, {
        key: "hide_eventGroupId",
        value: function hide_eventGroupId() {
          this.hideeventGroupId = false;
          this.event = "";
        }
      }]);

      return UpdateEventsDetailsComponent;
    }();

    UpdateEventsDetailsComponent.ɵfac = function UpdateEventsDetailsComponent_Factory(t) {
      return new (t || UpdateEventsDetailsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_update_service__WEBPACK_IMPORTED_MODULE_1__["UpdateService"]));
    };

    UpdateEventsDetailsComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: UpdateEventsDetailsComponent,
      selectors: [["app-update-events-details"]],
      decls: 46,
      vars: 6,
      consts: [[1, "container"], [1, "container", "mt-5"], ["form2", ""], [1, "form-group", "row", "justify-content-center"], ["for", "evnviornment", 1, "col-sm-2", "col-form-label"], [1, "col-3"], ["id", "evnviornment", 1, "form-control"], ["environment", ""], ["for", "trackingId", 1, "col-sm-2", "col-form-label"], ["type", "text", "id", "trackingId", 1, "form-control"], ["trackingId", ""], ["for", "status", 1, "col-sm-2", "col-form-label"], ["type", "text", "id", "status", 1, "form-control"], ["Status", ""], ["class", "form-group row", 4, "ngIf"], ["type", "button", 1, "btn", "btn-primary", "col-2", 2, "margin", "2px", 3, "click"], [1, "form-group", "row", "justify-content-center", "mt-5", 2, "width", "45%", "margin", "auto"], ["rows", "10", 1, "form-control"], ["jsondata", ""], ["value", "click to copy", 1, "my-5", "btn", "btn-success", 3, "click"], [1, "form-group", "row"], ["for", "dataJson", 1, "col-sm-2", "col-form-label", 2, "margin-left", "29%"], ["type", "Text", "id", "dataJson", "name", "data", 1, "form-control", 3, "ngModel", "ngModelChange"], ["type", "button", 1, "btn", "btn-danger", 3, "click"], ["for", "eventGroupId", 1, "col-sm-2", "col-form-label", 2, "margin-left", "29%"], ["type", "text", "id", "eventGroupId", "name", "eventGroupId", 1, "form-control", 3, "ngModel", "ngModelChange"], ["gId", ""], ["for", "responseMsg", 1, "col-sm-2", "col-form-label", 2, "margin-left", "29%"], ["type", "Text", "id", "responseMsg", "name", "msg", 1, "form-control", 3, "ngModel", "ngModelChange"], ["for", "serviceConsumerKey", 1, "col-sm-2", "col-form-label", 2, "margin-left", "29%"], ["type", "Text", "id", "serviceConsumerKey", "name", "scKey", 1, "form-control", 3, "ngModel", "ngModelChange"], ["for", "transactionRawJson", 1, "col-sm-2", "col-form-label", 2, "margin-left", "29%"], ["type", "Text", "id", "transactionRawJson", "name", "transactionRawJson", 1, "form-control", 3, "ngModel", "ngModelChange"]],
      template: function UpdateEventsDetailsComponent_Template(rf, ctx) {
        if (rf & 1) {
          var _r52 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "form", null, 2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "label", 4);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, "Environment");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 5);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "select", 6, 7);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "option");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, "DEV");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "option");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, "QA");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "option");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15, "UAT");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "option");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](17, "PROD");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "div", 3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "label", 8);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](20, "Tracker Id");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "div", 5);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](22, "input", 9, 10);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "div", 3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "label", 11);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](26, "Status");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "div", 5);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](28, "input", 12, 13);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](30, UpdateEventsDetailsComponent_div_30_Template, 7, 1, "div", 14);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](31, UpdateEventsDetailsComponent_div_31_Template, 8, 1, "div", 14);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](32, UpdateEventsDetailsComponent_div_32_Template, 7, 1, "div", 14);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](33, UpdateEventsDetailsComponent_div_33_Template, 8, 1, "div", 14);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](34, UpdateEventsDetailsComponent_div_34_Template, 8, 1, "div", 14);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](35, "div", 3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "button", 15);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function UpdateEventsDetailsComponent_Template_button_click_36_listener() {
            return ctx.onAddMore();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](37, " Add more ");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "button", 15);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function UpdateEventsDetailsComponent_Template_button_click_38_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r52);

            var _r25 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](9);

            var _r26 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](23);

            var _r27 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](29);

            return ctx.onAdd(_r25.value, _r26.value, _r27.value);
          })("click", function UpdateEventsDetailsComponent_Template_button_click_38_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r52);

            var _r24 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](3);

            return ctx.clear(_r24);
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](39, " Update ");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](40, "div", 16);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](41, "textarea", 17, 18);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](43);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](44, "button", 19);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function UpdateEventsDetailsComponent_Template_button_click_44_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r52);

            var _r33 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](42);

            return ctx.copyInputMessage(_r33);
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](45, " Copy ");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](30);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.hidedataJson);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.hideeventGroupId);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.hideResponse);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.hideserviceConsumerKey);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.hidetransactionRawJson);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](9);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.json);
        }
      },
      directives: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgForm"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgSelectOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵangular_packages_forms_forms_x"], _angular_common__WEBPACK_IMPORTED_MODULE_3__["NgIf"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgModel"]],
      styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3VwZGF0ZS1ldmVudHMtZGV0YWlscy91cGRhdGUtZXZlbnRzLWRldGFpbHMuY29tcG9uZW50LmNzcyJ9 */"]
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](UpdateEventsDetailsComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
          selector: "app-update-events-details",
          templateUrl: "./update-events-details.component.html",
          styleUrls: ["./update-events-details.component.css"]
        }]
      }], function () {
        return [{
          type: _update_service__WEBPACK_IMPORTED_MODULE_1__["UpdateService"]
        }];
      }, null);
    })();
    /***/

  },

  /***/
  "./src/app/update.service.ts":
  /*!***********************************!*\
    !*** ./src/app/update.service.ts ***!
    \***********************************/

  /*! exports provided: UpdateService */

  /***/
  function srcAppUpdateServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "UpdateService", function () {
      return UpdateService;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _update_update__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./update/update */
    "./src/app/update/update.ts");
    /* harmony import */


    var _Details__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./Details */
    "./src/app/Details.ts");
    /* harmony import */


    var _Details2__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./Details2 */
    "./src/app/Details2.ts");
    /* harmony import */


    var _update_update2__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./update/update2 */
    "./src/app/update/update2.ts");

    var UpdateService =
    /*#__PURE__*/
    function () {
      function UpdateService() {
        _classCallCheck(this, UpdateService);

        this.entry = [];
        this.jsonDev = [];
        this.jsonQa = [];
        this.jsonUat = [];
        this.jsonProd = [];
        this.jsonDev4 = [];
        this.jsonQa4 = [];
        this.jsonUat4 = [];
        this.jsonProd4 = [];
        this.trackArr = [];
        this.trackArr1 = [];
        this.trackArr2 = [];
      }

      _createClass(UpdateService, [{
        key: "withoutDataJsonUED",
        value: function withoutDataJsonUED(environment, trackerId, status, event, responseMsg, serviceConsumerKey, transactionRawJson) {
          var flag = 0;
          this.enviroment = environment;
          this.trackArr2 = trackerId.split(",");
          console.log(this.trackArr2);

          for (var i = 0; i < this.trackArr2.length; i++) {
            if (environment == "DEV") {
              for (var j = 0; j < this.jsonDev4.length; j++) {
                if (this.jsonDev4[j].detailsTrackerId == Number(this.trackArr2[i])) {
                  this.jsonDev4[j] = new _update_update2__WEBPACK_IMPORTED_MODULE_4__["Update2"](Number(this.trackArr2[i]), status, responseMsg, event, serviceConsumerKey, transactionRawJson);
                  flag = 1;
                  break;
                }
              }

              if (flag == 0) {
                this.jsonDev4.push(new _update_update2__WEBPACK_IMPORTED_MODULE_4__["Update2"](Number(this.trackArr2[i]), status, responseMsg, event, serviceConsumerKey, transactionRawJson));
              }
            } else if (environment == "QA") {
              for (var _j = 0; _j < this.jsonQa4.length; _j++) {
                if (this.jsonQa4[_j].detailsTrackerId == Number(this.trackArr2[i])) {
                  this.jsonQa4[_j] = new _update_update2__WEBPACK_IMPORTED_MODULE_4__["Update2"](Number(this.trackArr2[i]), status, responseMsg, event, serviceConsumerKey, transactionRawJson);
                  flag = 1;
                  break;
                }
              }

              if (flag == 0) {
                this.jsonQa4.push(new _update_update2__WEBPACK_IMPORTED_MODULE_4__["Update2"](Number(this.trackArr2[i]), status, responseMsg, event, serviceConsumerKey, transactionRawJson));
              }
            } else if (environment == "UAT") {
              for (var _j2 = 0; _j2 < this.jsonUat4.length; _j2++) {
                if (this.jsonUat4[_j2].detailsTrackerId == Number(this.trackArr2[i])) {
                  this.jsonUat4[_j2] = new _update_update2__WEBPACK_IMPORTED_MODULE_4__["Update2"](Number(this.trackArr2[i]), status, responseMsg, event, serviceConsumerKey, transactionRawJson);
                  flag = 1;
                  break;
                }
              }

              if (flag == 0) {
                this.jsonUat4.push(new _update_update2__WEBPACK_IMPORTED_MODULE_4__["Update2"](Number(this.trackArr2[i]), status, responseMsg, event, serviceConsumerKey, transactionRawJson));
              }
            } else if (environment == "PROD") {
              for (var _j3 = 0; _j3 < this.jsonProd4.length; _j3++) {
                if (this.jsonProd4[_j3].detailsTrackerId == Number(this.trackArr2[i])) {
                  this.jsonProd4[_j3] = new _update_update2__WEBPACK_IMPORTED_MODULE_4__["Update2"](Number(this.trackArr2[i]), status, responseMsg, event, serviceConsumerKey, transactionRawJson);
                  flag = 1;
                  break;
                }
              }

              if (flag == 0) {
                this.jsonProd4.push(new _update_update2__WEBPACK_IMPORTED_MODULE_4__["Update2"](Number(this.trackArr2[i]), status, responseMsg, event, serviceConsumerKey, transactionRawJson));
              }
            }
          }
        }
      }, {
        key: "addUpdateEventDetails",
        value: function addUpdateEventDetails(environment, trackerId, status, dataJson, eventGroupId, responseMsg, serviceConsumerKey, transactionRawJson) {
          var flag = 0;
          this.enviroment = environment;
          this.trackArr1 = trackerId.split(",");
          console.log(this.trackArr1);

          for (var i = 0; i < this.trackArr1.length; i++) {
            if (environment == "DEV") {
              for (var j = 0; j < this.jsonDev4.length; j++) {
                if (this.jsonDev4[j].detailsTrackerId == Number(this.trackArr2[i])) {
                  this.jsonDev4[j] = new _update_update__WEBPACK_IMPORTED_MODULE_1__["Update"](Number(this.trackArr1[i]), status, dataJson, eventGroupId, responseMsg, serviceConsumerKey, transactionRawJson);
                  flag = 1;
                  break;
                }
              }

              if (flag == 0) {
                this.jsonDev4.push(new _update_update__WEBPACK_IMPORTED_MODULE_1__["Update"](Number(this.trackArr1[i]), status, dataJson, eventGroupId, responseMsg, serviceConsumerKey, transactionRawJson));
              }
            } else if (environment == "QA") {
              for (var _j4 = 0; _j4 < this.jsonQa4.length; _j4++) {
                if (this.jsonQa4[_j4].detailsTrackerId == Number(this.trackArr2[i])) {
                  this.jsonQa4[_j4] = new _update_update__WEBPACK_IMPORTED_MODULE_1__["Update"](Number(this.trackArr1[i]), status, dataJson, responseMsg, eventGroupId, serviceConsumerKey, transactionRawJson);
                  flag = 1;
                  break;
                }
              }

              if (flag == 0) {
                this.jsonQa4.push(new _update_update__WEBPACK_IMPORTED_MODULE_1__["Update"](Number(this.trackArr1[i]), status, dataJson, responseMsg, eventGroupId, serviceConsumerKey, transactionRawJson));
              }
            } else if (environment == "UAT") {
              for (var _j5 = 0; _j5 < this.jsonUat4.length; _j5++) {
                if (this.jsonUat4[_j5].detailsTrackerId == Number(this.trackArr2[i])) {
                  this.jsonUat4[_j5] = new _update_update__WEBPACK_IMPORTED_MODULE_1__["Update"](Number(this.trackArr1[i]), status, dataJson, responseMsg, eventGroupId, serviceConsumerKey, transactionRawJson);
                  flag = 1;
                  break;
                }
              }

              if (flag == 0) {
                this.jsonUat4.push(new _update_update__WEBPACK_IMPORTED_MODULE_1__["Update"](Number(this.trackArr1[i]), status, dataJson, responseMsg, eventGroupId, serviceConsumerKey, transactionRawJson));
              }
            } else if (environment == "PROD") {
              for (var _j6 = 0; _j6 < this.jsonProd4.length; _j6++) {
                if (this.jsonProd4[_j6].detailsTrackerId == Number(this.trackArr2[i])) {
                  this.jsonProd4[_j6] = new _update_update__WEBPACK_IMPORTED_MODULE_1__["Update"](Number(this.trackArr1[i]), status, dataJson, responseMsg, eventGroupId, serviceConsumerKey, transactionRawJson);
                  flag = 1;
                  break;
                }
              }

              if (flag == 0) {
                this.jsonProd4.push(new _update_update__WEBPACK_IMPORTED_MODULE_1__["Update"](Number(this.trackArr1[i]), status, dataJson, responseMsg, eventGroupId, serviceConsumerKey, transactionRawJson));
              }
            }
          }
        } //update components

      }, {
        key: "add",
        value: function add(env, track, status, data, response, group) {
          this.enviroment = env;
          console.log(typeof track);
          this.trackArr = track.split(",");
          console.log(this.trackArr);
          var flag = 0;

          for (var i = 0; i < this.trackArr.length; i++) {
            if (env == "DEV") {
              for (var j = 0; j < this.jsonDev.length; j++) {
                if (this.jsonDev[j].trackerId == Number(this.trackArr[i])) {
                  this.jsonDev[j] = new _Details__WEBPACK_IMPORTED_MODULE_2__["Details"](Number(this.trackArr[i]), status, data, response, group);
                  flag = 1;
                  break;
                }
              }

              if (flag == 0) {
                this.jsonDev.push(new _Details__WEBPACK_IMPORTED_MODULE_2__["Details"](Number(this.trackArr[i]), status, data, response, group));
              }
            } else if (env == "QA") {
              for (var _j7 = 0; _j7 < this.jsonQa.length; _j7++) {
                if (this.jsonQa[_j7].trackerId == Number(this.trackArr[i])) {
                  this.jsonQa[_j7] = new _Details__WEBPACK_IMPORTED_MODULE_2__["Details"](Number(this.trackArr[i]), status, data, response, group);
                  flag = 1;
                  break;
                }
              }

              if (flag == 0) {
                this.jsonQa.push(new _Details__WEBPACK_IMPORTED_MODULE_2__["Details"](Number(this.trackArr[i]), status, data, response, group));
              }
            } else if (env == "UAT") {
              for (var _j8 = 0; _j8 < this.jsonUat.length; _j8++) {
                if (this.jsonUat[_j8].trackerId == Number(this.trackArr[i])) {
                  this.jsonUat[_j8] = new _Details__WEBPACK_IMPORTED_MODULE_2__["Details"](Number(this.trackArr[i]), status, data, response, group);
                  flag = 1;
                  break;
                }
              }

              if (flag == 0) {
                this.jsonUat.push(new _Details__WEBPACK_IMPORTED_MODULE_2__["Details"](Number(this.trackArr[i]), status, data, response, group));
              }
            } else if (env == "PROD") {
              for (var _j9 = 0; _j9 < this.jsonProd.length; _j9++) {
                if (this.jsonProd[_j9].trackerId == Number(this.trackArr[i])) {
                  this.jsonProd[_j9] = new _Details__WEBPACK_IMPORTED_MODULE_2__["Details"](Number(this.trackArr[i]), status, data, response, group);
                  flag = 1;
                  break;
                }
              }

              if (flag == 0) {
                this.jsonProd.push(new _Details__WEBPACK_IMPORTED_MODULE_2__["Details"](Number(this.trackArr[i]), status, data, response, group));
              }
            }
          }
        }
      }, {
        key: "withoutDataJson",
        value: function withoutDataJson(environment, trackerId, status, response, group) {
          this.enviroment = environment;
          this.trackArr = trackerId.split(",");
          console.log(this.trackArr);
          var flag = 0;

          for (var i = 0; i < this.trackArr.length; i++) {
            if (environment == "DEV") {
              for (var j = 0; j < this.jsonDev.length; j++) {
                if (this.jsonDev[j].trackerId == Number(this.trackArr[i])) {
                  this.jsonDev[j] = new _Details2__WEBPACK_IMPORTED_MODULE_3__["Details2"](Number(this.trackArr[i]), status, response, group);
                  flag = 1;
                  break;
                }
              }

              if (flag == 0) {
                this.jsonDev.push(new _Details2__WEBPACK_IMPORTED_MODULE_3__["Details2"](Number(this.trackArr[i]), status, response, group));
              }
            } else if (this.enviroment == "QA") {
              for (var _j10 = 0; _j10 < this.jsonQa.length; _j10++) {
                if (this.jsonQa[_j10].trackerId == Number(this.trackArr[i])) {
                  this.jsonQa[_j10] = new _Details2__WEBPACK_IMPORTED_MODULE_3__["Details2"](Number(this.trackArr[i]), status, response, group);
                  flag = 1;
                  break;
                }
              }

              if (flag == 0) {
                this.jsonQa.push(new _Details2__WEBPACK_IMPORTED_MODULE_3__["Details2"](Number(this.trackArr[i]), status, response, group));
              }
            } else if (this.enviroment == "UAT") {
              for (var _j11 = 0; _j11 < this.jsonUat.length; _j11++) {
                if (this.jsonUat[_j11].trackerId == Number(this.trackArr[i])) {
                  this.jsonUat[_j11] = new _Details2__WEBPACK_IMPORTED_MODULE_3__["Details2"](Number(this.trackArr[i]), status, response, group);
                  flag = 1;
                  break;
                }
              }

              if (flag == 0) {
                this.jsonUat.push(new _Details2__WEBPACK_IMPORTED_MODULE_3__["Details2"](Number(this.trackArr[i]), status, response, group));
              }
            } else if (this.enviroment == "PROD") {
              for (var _j12 = 0; _j12 < this.jsonProd.length; _j12++) {
                if (this.jsonProd[_j12].trackerId == Number(this.trackArr[i])) {
                  this.jsonProd[_j12] = new _Details2__WEBPACK_IMPORTED_MODULE_3__["Details2"](Number(this.trackArr[i]), status, response, group);
                  flag = 1;
                  break;
                }
              }

              if (flag == 0) {
                this.jsonProd.push(new _Details2__WEBPACK_IMPORTED_MODULE_3__["Details2"](Number(this.trackArr[i]), status, response, group));
              }
            }
          }
        }
      }, {
        key: "getjson",
        value: function getjson() {
          if (this.enviroment == "DEV") {
            this.result = this.jsonDev;
          } else if (this.enviroment == "QA") {
            this.result = this.jsonQa;
          } else if (this.enviroment == "UAT") {
            this.result = this.jsonUat;
          } else if (this.enviroment == "PROD") {
            this.result = this.jsonProd;
          }

          console.log("result of update");
          console.log(this.result);
          return JSON.stringify(this.result, null, 4);
        }
      }, {
        key: "getjsonupdateeventdetails",
        value: function getjsonupdateeventdetails() {
          if (this.enviroment == "DEV") {
            this.result = this.jsonDev4;
          } else if (this.enviroment == "QA") {
            this.result = this.jsonQa4;
          } else if (this.enviroment == "UAT") {
            this.result = this.jsonUat4;
          } else if (this.enviroment == "PROD") {
            this.result = this.jsonProd4;
          }

          console.log("result");
          console.log(this.result);
          return JSON.stringify(this.result, null, 4);
        }
      }]);

      return UpdateService;
    }();

    UpdateService.ɵfac = function UpdateService_Factory(t) {
      return new (t || UpdateService)();
    };

    UpdateService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
      token: UpdateService,
      factory: UpdateService.ɵfac,
      providedIn: "root"
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](UpdateService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
          providedIn: "root"
        }]
      }], function () {
        return [];
      }, null);
    })();
    /***/

  },

  /***/
  "./src/app/update/update.component.ts":
  /*!********************************************!*\
    !*** ./src/app/update/update.component.ts ***!
    \********************************************/

  /*! exports provided: UpdateComponent */

  /***/
  function srcAppUpdateUpdateComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "UpdateComponent", function () {
      return UpdateComponent;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _update_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ../update.service */
    "./src/app/update.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");

    function UpdateComponent_div_30_Template(rf, ctx) {
      if (rf & 1) {
        var _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 3);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "label", 21);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Data JSON");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 5);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "input", 22);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function UpdateComponent_div_30_Template_input_ngModelChange_4_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r14);

          var ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r13.dataJson = $event;
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "button", 23);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function UpdateComponent_div_30_Template_button_click_5_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r14);

          var ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r15.hide_data();
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, " Delete ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx_r9.dataJson);
      }
    }

    function UpdateComponent_div_31_Template(rf, ctx) {
      if (rf & 1) {
        var _r17 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 3);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "label", 24);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Response Message");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 5);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "input", 25);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function UpdateComponent_div_31_Template_input_ngModelChange_4_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r17);

          var ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r16.responseMsg = $event;
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "button", 23);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function UpdateComponent_div_31_Template_button_click_5_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r17);

          var ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r18.hide_res();
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, " Delete ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx_r10.responseMsg);
      }
    }

    function UpdateComponent_div_32_Template(rf, ctx) {
      if (rf & 1) {
        var _r21 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 3);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "label", 26);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Event Group Id");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 5);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "input", 27, 28);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function UpdateComponent_div_32_Template_input_ngModelChange_4_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r21);

          var ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r20.groupId = $event;
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "button", 23);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function UpdateComponent_div_32_Template_button_click_6_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r21);

          var ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r22.hide_group();
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, " Delete ");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx_r11.groupId);
      }
    }

    var UpdateComponent =
    /*#__PURE__*/
    function () {
      function UpdateComponent(service) {
        _classCallCheck(this, UpdateComponent);

        this.service = service;
        this.environment = "";
        this.status = "";
        this.add = false;
        this.hideGroup = false;
        this.hideResponse = false;
        this.hideData = false;
      }

      _createClass(UpdateComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "onAdd",
        value: function onAdd(env, id, status) {
          this.environment = env;
          this.trackerId = id;
          this.status = status.toUpperCase();
          if (this.groupId == "") this.groupId = 0;

          if (!this.dataJson) {
            this.service.withoutDataJson(this.environment, this.trackerId, this.status, this.responseMsg, this.groupId);
            this.json = this.service.getjson();
          } else {
            if (String(this.dataJson).length > 0) {
              this.service.add(this.environment, this.trackerId, this.status, this.dataJson, this.responseMsg, this.groupId);
              this.json = this.service.getjson();
            } else {
              this.service.withoutDataJson(this.environment, this.trackerId, this.status, this.responseMsg, this.groupId);
              this.json = this.service.getjson();
            }
          } // this.json = this.service.getjson();


          this.dataJson = "";
          this.responseMsg = "";
          this.groupId = "";
          this.hideGroup = false;
          this.hideResponse = false;
          this.hideData = false;
        }
      }, {
        key: "onAddMore",
        value: function onAddMore() {
          // this.add = true;
          this.hideGroup = true;
          this.hideResponse = true;
          this.hideData = true;
        }
      }, {
        key: "clear",
        value: function clear(form1) {
          form1.reset();
        }
      }, {
        key: "hide_data",
        value: function hide_data() {
          this.hideData = false;
          this.dataJson = "";
        }
      }, {
        key: "hide_res",
        value: function hide_res() {
          this.hideResponse = false;
          this.responseMsg = "";
        }
      }, {
        key: "hide_group",
        value: function hide_group() {
          this.groupId = "";
          this.hideGroup = false;
        }
      }, {
        key: "copyInputMessage",
        value: function copyInputMessage(inputElement) {
          inputElement.select();
          document.execCommand("copy");
          inputElement.setSelectionRange(0, 0);
        }
      }]);

      return UpdateComponent;
    }();

    UpdateComponent.ɵfac = function UpdateComponent_Factory(t) {
      return new (t || UpdateComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_update_service__WEBPACK_IMPORTED_MODULE_1__["UpdateService"]));
    };

    UpdateComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: UpdateComponent,
      selectors: [["app-update"]],
      decls: 44,
      vars: 4,
      consts: [[1, "container"], [1, "container", "mt-5"], ["form1", ""], [1, "form-group", "row"], ["for", "evnviornment", 1, "col-sm-2", "col-form-label", 2, "margin-left", "29%"], [1, "col-3"], ["id", "evnviornment", 1, "form-control"], ["environment", ""], ["for", "trackingId", 1, "col-sm-2", "col-form-label", 2, "margin-left", "29%"], ["type", "Text", "id", "trackingId", 1, "form-control"], ["trackingId", ""], ["for", "status", 1, "col-sm-2", "col-form-label", 2, "margin-left", "29%"], ["type", "Text", "id", "s", 1, "form-control"], ["status", ""], ["class", "form-group row", 4, "ngIf"], [1, "form-group", "row", "justify-content-center"], ["type", "button", 1, "btn", "btn-primary", "col-2", 2, "margin", "2px", 3, "click"], [1, "form-group", "row", "justify-content-center", "mt-5", 2, "width", "45%", "margin", "auto"], ["rows", "10", 1, "form-control"], ["jsondata", ""], ["value", "click to copy", 1, "my-5", "btn", "btn-success", 3, "click"], ["for", "dataJson", 1, "col-sm-2", "col-form-label", 2, "margin-left", "29%"], ["type", "Text", "id", "dataJson", "name", "data", 1, "form-control", 3, "ngModel", "ngModelChange"], ["type", "button", 1, "btn", "btn-danger", 3, "click"], ["for", "responseMsg", 1, "col-sm-2", "col-form-label", 2, "margin-left", "29%"], ["type", "Text", "id", "responseMsg", "name", "msg", 1, "form-control", 3, "ngModel", "ngModelChange"], ["for", "groupId", 1, "col-sm-2", "col-form-label", 2, "margin-left", "29%"], ["type", "number", "id", "groupId", "name", "group", 1, "form-control", 3, "ngModel", "ngModelChange"], ["gId", ""]],
      template: function UpdateComponent_Template(rf, ctx) {
        if (rf & 1) {
          var _r23 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "form", null, 2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "label", 4);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, "Environment");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 5);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "select", 6, 7);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "option");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, "DEV");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "option");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, "QA");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "option");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15, "UAT");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "option");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](17, "PROD");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "div", 3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "label", 8);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](20, "Tracker Id");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "div", 5);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](22, "input", 9, 10);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "div", 3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "label", 11);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](26, "Status");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "div", 5);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](28, "input", 12, 13);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](30, UpdateComponent_div_30_Template, 7, 1, "div", 14);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](31, UpdateComponent_div_31_Template, 7, 1, "div", 14);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](32, UpdateComponent_div_32_Template, 8, 1, "div", 14);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](33, "div", 15);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](34, "button", 16);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function UpdateComponent_Template_button_click_34_listener() {
            return ctx.onAddMore();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](35, " Add more ");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "button", 16);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function UpdateComponent_Template_button_click_36_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r23);

            var _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](9);

            var _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](23);

            var _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](29);

            return ctx.onAdd(_r6.value, _r7.value, _r8.value);
          })("click", function UpdateComponent_Template_button_click_36_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r23);

            var _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](3);

            return ctx.clear(_r5);
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](37, " Update ");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "div", 17);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](39, "textarea", 18, 19);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](41);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](42, "button", 20);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function UpdateComponent_Template_button_click_42_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r23);

            var _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](40);

            return ctx.copyInputMessage(_r12);
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](43, " Copy ");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](30);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.hideData);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.hideResponse);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.hideGroup);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](9);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.json);
        }
      },
      directives: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgForm"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgSelectOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵangular_packages_forms_forms_x"], _angular_common__WEBPACK_IMPORTED_MODULE_3__["NgIf"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgModel"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NumberValueAccessor"]],
      styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3VwZGF0ZS91cGRhdGUuY29tcG9uZW50LmNzcyJ9 */"]
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](UpdateComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
          selector: "app-update",
          templateUrl: "./update.component.html",
          styleUrls: ["./update.component.css"]
        }]
      }], function () {
        return [{
          type: _update_service__WEBPACK_IMPORTED_MODULE_1__["UpdateService"]
        }];
      }, null);
    })();
    /***/

  },

  /***/
  "./src/app/update/update.ts":
  /*!**********************************!*\
    !*** ./src/app/update/update.ts ***!
    \**********************************/

  /*! exports provided: Update */

  /***/
  function srcAppUpdateUpdateTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Update", function () {
      return Update;
    });

    var Update = function Update(detailsTrackerId, status) {
      var dataJson = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : "";
      var event = arguments.length > 3 ? arguments[3] : undefined;
      var responseMsg = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : "";
      var serviceConsumerKey = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : "";
      var transactionRawJson = arguments.length > 6 && arguments[6] !== undefined ? arguments[6] : "";

      _classCallCheck(this, Update);

      // this.environment = environment;
      this.detailsTrackerId = detailsTrackerId;
      this.status = status;
      this.dataJson = dataJson;
      this.event = event;
      this.responseMsg = responseMsg;
      this.serviceConsumerKey = serviceConsumerKey;
      this.transactionRawJson = transactionRawJson;
    };
    /***/

  },

  /***/
  "./src/app/update/update2.ts":
  /*!***********************************!*\
    !*** ./src/app/update/update2.ts ***!
    \***********************************/

  /*! exports provided: Update2 */

  /***/
  function srcAppUpdateUpdate2Ts(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Update2", function () {
      return Update2;
    });

    var Update2 = function Update2(detailsTrackerId, status) {
      var responseMsg = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : "";
      var event = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : "";
      var serviceConsumerKey = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : "";
      var transactionRawJson = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : "";

      _classCallCheck(this, Update2);

      // this.environment = environment;
      this.detailsTrackerId = detailsTrackerId;
      this.status = status; //   this.dataJson=dataJson;

      this.event = event;
      this.responseMsg = responseMsg;
      this.serviceConsumerKey = serviceConsumerKey;
      this.transactionRawJson = transactionRawJson;
    };
    /***/

  },

  /***/
  "./src/environments/environment.ts":
  /*!*****************************************!*\
    !*** ./src/environments/environment.ts ***!
    \*****************************************/

  /*! exports provided: environment */

  /***/
  function srcEnvironmentsEnvironmentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "environment", function () {
      return environment;
    }); // This file can be replaced during build by using the `fileReplacements` array.
    // `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
    // The list of file replacements can be found in `angular.json`.


    var environment = {
      production: false
    };
    /*
     * For easier debugging in development mode, you can import the following file
     * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
     *
     * This import should be commented out in production mode because it will have a negative impact
     * on performance if an error is thrown.
     */
    // import 'zone.js/dist/zone-error';  // Included with Angular CLI.

    /***/
  },

  /***/
  "./src/main.ts":
  /*!*********************!*\
    !*** ./src/main.ts ***!
    \*********************/

  /*! no exports provided */

  /***/
  function srcMainTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./app/app.module */
    "./src/app/app.module.ts");
    /* harmony import */


    var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/platform-browser */
    "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");

    if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].production) {
      Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
    }

    _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["platformBrowser"]().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])["catch"](function (err) {
      return console.error(err);
    });
    /***/

  },

  /***/
  0:
  /*!***************************!*\
    !*** multi ./src/main.ts ***!
    \***************************/

  /*! no static exports found */

  /***/
  function _(module, exports, __webpack_require__) {
    module.exports = __webpack_require__(
    /*! D:\Applications\Angular\Event-Update-Utility\src\main.ts */
    "./src/main.ts");
    /***/
  }
}, [[0, "runtime", "vendor"]]]);
//# sourceMappingURL=main-es5.js.map